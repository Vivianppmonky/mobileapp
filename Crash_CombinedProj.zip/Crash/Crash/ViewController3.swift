//
//  ViewController3.swift
//  Crash
//
//  Created by Shaza Khalifah on 06/10/2017.
//

import UIKit
import MessageUI
import CoreLocation


class ViewController3: UIViewController, MFMessageComposeViewControllerDelegate, CLLocationManagerDelegate {
    let location_Manager = CLLocationManager()
    var current_Location: CLLocation!
    var user_Latitude : Double = 0.0
    var user_Longitude : Double = 0.0
    var phone_Number: String = ""
    
    @IBAction func AmbulanceButton(_ sender: Any) {
        phone_Number = "tel://1300366141"
        self.makeAPhoneCall(callNumber: phone_Number)
    }
    
    @IBAction func EmergencyButton(_ sender: Any) {
        let emergency_contact: String = "0414390641"
        self.sendMessage(emergencycontact: emergency_contact)
    }
    
    @IBAction func BothButton(_ sender: Any) {
        let emergency_contact: String = "0414390641"
        let phone_Number: String = "tel://1300366141"
        self.sendMessage(emergencycontact: emergency_contact)
        self.makeAPhoneCall(callNumber: phone_Number)
    }
    
        
    override func viewDidLoad() {
        super.viewDidLoad()
        
        location_Manager.delegate = self
        location_Manager.desiredAccuracy = kCLLocationAccuracyBest
        location_Manager.requestWhenInUseAuthorization()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        locationCoordinate ()
    }
    
    func locationCoordinate () {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            current_Location = location_Manager.location
        } else {
            location_Manager.requestWhenInUseAuthorization()
        }
        user_Latitude = current_Location.coordinate.latitude
        user_Longitude = current_Location.coordinate.longitude
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    func makeAPhoneCall(callNumber: String)  {
        let url:NSURL = URL(string: callNumber)! as NSURL
        UIApplication.shared.open(url as URL, options: [:], completionHandler: nil)
    }
    
    func sendMessage(emergencycontact: String){
        if(MFMessageComposeViewController.canSendText()){
            let latitude: String = String(user_Latitude)
            let longitude: String = String(user_Longitude)
            let controller = MFMessageComposeViewController ()
            controller.body = "Hi there! I am in terrible situation find me here: http://www.google.com/maps/place/" + latitude + "," + longitude
            controller.recipients = [emergencycontact]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    

    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
