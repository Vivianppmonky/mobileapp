//
//  ViewController2.swift
//  Crash
//
//  Created by AMHFA on 1/10/17.
//

import UIKit
import AVFoundation

class ViewController2: UIViewController {
    
    @IBOutlet weak var timerLabel: UILabel!
    
    var seconds = 15
    var isTimerRunning = false
    var timer = Timer()
    var audioPlayer = AVAudioPlayer()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        do {
            audioPlayer = try AVAudioPlayer(contentsOf: URL.init(fileURLWithPath:Bundle.main.path(forResource: "alarm", ofType: "mp3")!))
            audioPlayer.numberOfLoops = -1
            audioPlayer.play()
        }
        catch{
            print(error)
        }
        runTimer()
        // Do any additional setup after loading the view.
    }
    

    func runTimer() {
        timer = Timer.scheduledTimer(timeInterval: 1, target: self, selector: #selector(ViewController2.updateTimer), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer() {
        seconds -= 1
        timerLabel.text = "00:" + "\(seconds)"
        
        if (seconds == 0){
            audioPlayer.stop()
            //Shaza - call emergency services
        }
    }
    
    
    @IBAction func Cancel(_ sender: Any) {
        audioPlayer.stop()
        performSegue(withIdentifier: "Cancel", sender: self)
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
