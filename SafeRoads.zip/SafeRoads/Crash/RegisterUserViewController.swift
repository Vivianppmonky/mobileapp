//
//  RegisterUserViewController.swift
//  Crash
//
//  Created by Vivian Zhang on 07/10/2017.
//

import UIKit

class RegisterUserViewController: UIViewController {

    @IBOutlet weak var fullName: UITextField!
    
    @IBOutlet weak var userPassword: UITextField!
    
    @IBOutlet weak var emergencyContactName: UITextField!
    
    @IBOutlet weak var emergencyContactNumber: UITextField!
    
    let defaults = UserDefaults.standard
    
    // Cancle the sign up process and redirect to log in page
    @IBAction func cancleButton(_ sender: Any) {
        print("cancel button tapped.")
        dismiss(animated: true, completion: nil)
    }
    // Register a new user
    @IBAction func signupButton(_ sender: Any) {
        print("sign up button tapped.")
        // Prevent registration process from empty registration entry
        if (fullName.text == "") || (userPassword.text == "") || (emergencyContactName.text == "") || (emergencyContactNumber.text == ""){
            let alert = UIAlertController(title: "Oops", message: "All fields are required to enter!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert,animated: true, completion: nil)
            return
        }
        // Save the user info
        defaults.set(fullName.text!, forKey: "username")
        defaults.set(userPassword.text!, forKey: "userpassword")
        defaults.set(emergencyContactName.text!, forKey: "contactname")
        defaults.set(emergencyContactNumber.text!, forKey: "contactnumber")
        print("created a new user.")
        print(defaults.object(forKey: "username") as! String)
        print(defaults.object(forKey: "userpassword")as! String)
        print(defaults.object(forKey: "contactname") as! String)
        print(defaults.object(forKey: "contactnumber") as! String)
        dismiss(animated: true, completion: nil)
    }
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

   

}
