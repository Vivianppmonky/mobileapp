//
//  SigninViewController.swift
//  Crash
//
//  Created by Vivian Zhang on 07/10/2017.
//

import UIKit

class SigninViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userNameText: UITextField!
    @IBOutlet weak var userPasswordText: UITextField!
    let defaults = UserDefaults.standard
    
    @IBAction func signinButton(_ sender: Any) {
        print("Sign in button tapped.")
        if (userNameText.text == "") || (userPasswordText.text == ""){
            let emptyAlert = UIAlertController(title: "Oops", message: "Your username or password does not match our records!", preferredStyle: .alert)
            emptyAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(emptyAlert, animated: true, completion: nil)
            
        }
        // perform user authtication
        if defaults.object(forKey: "username") != nil {
            print("okkkk")
            let userFullName = defaults.object(forKey: "username") as! String
            let userPassword = defaults.object(forKey: "userpassword") as! String
            if (userNameText.text! == userFullName) && (userPasswordText.text! == userPassword) {
                print(userFullName)
                performSegue(withIdentifier: "signIn", sender:self)
            }
        
        resetField()
        // Pop up alert for incorrect username or password
        let unmatchAlert = UIAlertController(title: "Oops", message: "Your username or password does not match our records!", preferredStyle: .alert)
        unmatchAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        self.present(unmatchAlert, animated: true, completion: nil)
        }else {
            // Pop up alert for new user sign in
            let newUserAlert = UIAlertController(title: "Oops", message: "It seems like you are a new user, please sign up first!", preferredStyle: .alert)
            newUserAlert.addAction(UIAlertAction(title:"OK", style: .default, handler: nil))
            self.present(newUserAlert, animated: true, completion: nil)
        }
        
    }
    
    // Reset the username and password fields 
    @IBAction func resetButton(_ sender: Any) {
        resetField()
    }
    
    func resetField() {
        userNameText.text = ""
        userPasswordText.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        userNameText.resignFirstResponder()
        userPasswordText.resignFirstResponder()
        return true
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        userNameText.delegate = self
        userPasswordText.delegate = self
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}
