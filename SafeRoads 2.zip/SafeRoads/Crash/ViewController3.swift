//
//  ViewController3.swift
//  Crash
//
//  Created by Shaza Khalifah on 01/10/2017.
//

import UIKit
import MessageUI
import CoreLocation


class ViewController3: UIViewController, MFMessageComposeViewControllerDelegate, CLLocationManagerDelegate {
    let location_Manager = CLLocationManager()
    var current_Location: CLLocation!
    var user_Latitude : Double = 0.0
    var user_Longitude : Double = 0.0
    var phone_Number: String = ""
    
    //Emergency Service button: send user's current location to Emergency service
    //Emergency Service number is "0423677767", we didn't put it in code to avoid sending accidentally
    @IBAction func EmergencyService(_ sender: Any) {
        let emergency_service = "12121212"
        self.sendMessage(emergency_number: emergency_service)
    }
    
    //Emergency Contact button: send user's current location to his Emergency Contact e.g. parents
    @IBAction func EmergencyContact(_ sender: Any) {
        let emergency_contact = UserDefaults.standard.value(forKey: "contactnumber")
        self.sendMessage(emergency_number: emergency_contact as! String)
    }
    
    //Both of them button: send user's current location to both Emergency service and user Emergency Contact
    @IBAction func BothButton(_ sender: Any) {
        let emergency_service = "12121212"
        let emergency_contact = UserDefaults.standard.value(forKey: "contactnumber")
        self.broadcastMessage(emergency_number1: emergency_service , emergency_number2: emergency_contact as! String)
    }
    
    //Cancel button: return user to app default page which is the realtime map
    @IBAction func CancelButton(_ sender: Any) {
        performSegue(withIdentifier: "Cancel", sender: self)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        location_Manager.delegate = self
        location_Manager.desiredAccuracy = kCLLocationAccuracyBest
        location_Manager.requestWhenInUseAuthorization()
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(true)
        locationCoordinate ()
    }
    
    //This function to get user's current location
    func locationCoordinate () {
        if CLLocationManager.authorizationStatus() == .authorizedWhenInUse {
            current_Location = location_Manager.location
        } else {
            location_Manager.requestWhenInUseAuthorization()
        }
        user_Latitude = current_Location.coordinate.latitude
        user_Longitude = current_Location.coordinate.longitude
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    //This function to send the user's current location to either Emergency service or user Emergency Contact
    func sendMessage(emergency_number: String){
        if(MFMessageComposeViewController.canSendText()){
            let latitude: String = String(user_Latitude)
            let longitude: String = String(user_Longitude)
            let controller = MFMessageComposeViewController ()
            controller.body = "This is an auto message from the SafeRoads App. I have been in a road accident. Please send an ambulance to this location : http://www.google.com/maps/place/" + latitude + "," + longitude
            controller.recipients = [emergency_number]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    //This function to broadcast the user's current location to both Emergency service and his Emergency Contact at the same time
    func broadcastMessage(emergency_number1: String, emergency_number2: String){
        if(MFMessageComposeViewController.canSendText()){
            let latitude: String = String(user_Latitude)
            let longitude: String = String(user_Longitude)
            let controller = MFMessageComposeViewController ()
            controller.body = "This is an auto message from the SafeRoads App. I have been in a road accident. Please send an ambulance to this location : http://www.google.com/maps/place/" + latitude + "," + longitude
            controller.recipients = [emergency_number1, emergency_number2]
            controller.messageComposeDelegate = self
            self.present(controller, animated: true, completion: nil)
        }
    }
    
    func messageComposeViewController(_ controller: MFMessageComposeViewController, didFinishWith result: MessageComposeResult) {
        self.dismiss(animated: true, completion: nil)
    }
    
    
    
}


