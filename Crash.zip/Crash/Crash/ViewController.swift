//
//  ViewController.swift
//  Crash
//
//  Created by AMHFA on 30/9/17.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    
    var motionManager = CMMotionManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func viewDidAppear(_ animated: Bool) {
        motionManager.startAccelerometerUpdates(to: OperationQueue.current!){(data, Error) in
            if let myData = data{
                if (myData.acceleration.x > 4 || myData.acceleration.y > 4 || myData.acceleration.z > 4){
                    self.performSegue(withIdentifier: "Crash", sender: self)
                }
            }
            
        }
    }

        
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

}

