//
//  HomeViewController.swift
//  mobileapp
//
//  Created by Vivian Zhang on 06/10/2017.
//  Copyright © 2017 Vivian Zhang. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var contactName: UITextField!
    @IBOutlet weak var contactNumber: UITextField!
    @IBOutlet weak var contactinfo: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print("loaded home page.")
        
        // Do any additional setup after loading the view.
        // Display user's emergency contact name and number
        if let contactname = UserDefaults.standard.value(forKey: "contactname") as? String {
            contactName.text = contactname
        }
        if let contactnumber = UserDefaults.standard.value(forKey: "contactnumber") as? String {
            contactNumber.text = contactnumber
        }
            
    }
    
    // Press SignOut button to return to login page
    @IBAction func signoutButtontapped(_ sender: Any) {
        dismiss(animated: true, completion: nil)
    }
    // Add Contact will save the user's emergency contact
    @IBAction func addContactButton(_ sender: Any) {
        // Prevent form empty contact entry
        if (contactName.text == "") && (contactNumber.text == "") {
            let alertmsg = UIAlertController(title: "Oops", message: "All fields are required to enter!", preferredStyle: .alert)
            alertmsg.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alertmsg,animated: true, completion: nil)
            return
        }
        // Create user emergency contact
        let contactDefault = UserDefaults.standard
        contactDefault.set(contactName.text!, forKey: "contactname")
        contactDefault.set(contactNumber.text!, forKey: "contactnumber")
        let myObject = contactDefault.object(forKey: "contactname") as? String
        print(myObject ?? "NONE")
        
        
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    // Enable user to delete his/her account
    @IBAction func deleteAccountButton(_ sender: Any) {
        UserDefaults.standard.removeObject(forKey: "username")
        UserDefaults.standard.removeObject(forKey: "userpassword")
        UserDefaults.standard.removeObject(forKey: "contactname")
        UserDefaults.standard.removeObject(forKey: "contactnumber")
        UserDefaults.standard.synchronize()
        dismiss(animated: true, completion: nil)
    }
}
