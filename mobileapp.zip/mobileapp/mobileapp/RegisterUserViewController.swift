//
//  RegisterUserViewController.swift
//  mobileapp
//
//  Created by Vivian Zhang on 03/10/2017.
//  Copyright © 2017 Vivian Zhang. All rights reserved.
//

import UIKit

class RegisterUserViewController: UIViewController {

    @IBOutlet weak var fullName: UITextField!
    @IBOutlet weak var passwordText: UITextField!
    @IBOutlet weak var emergencyContactName: UITextField!
    @IBOutlet weak var emergencyContactNumber: UITextField!
    
    
    
    let defaults = UserDefaults.standard
    //var userFullNames = [String]()
   // var userPasswords = [String]()
    
    @IBAction func cancelButton(_ sender: Any) {
        print("cancel button tapped.")
        dismiss(animated: true, completion: nil)
    }
    
    @IBAction func signUpButton(_ sender: Any) {
        print("sign up button tapped.")
        // Prevent registration process from empty registration entry
        if (fullName.text == "") || (passwordText.text == "") || (emergencyContactName.text == "") || (emergencyContactNumber.text == ""){
            let alert = UIAlertController(title: "Oops", message: "All fields are required to enter!", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "Ok", style: .default, handler: nil))
            present(alert,animated: true, completion: nil)
            return
        }
        //if defaults.object(forKey: "userNames") != nil{
            //userFullNames = defaults.array(forKey: "userNames") as! [String]
            //userPasswords = defaults.array(forKey: "passwords") as! [String]
        //}
        // Create a new user account
        //userFullNames.insert(fullName.text!, at: userFullNames.count)
        //userPasswords.insert(passwordText.text!, at: userPasswords.count)
        //defaults.set(userFullNames, forKey: "userNames")
        //defaults.set(userPasswords, forKey: "passwords")
        defaults.set(fullName.text!, forKey: "username")
        defaults.set(passwordText.text!, forKey: "userpassword")
        defaults.set(emergencyContactName.text!, forKey: "contactname")
        defaults.set(emergencyContactNumber.text!, forKey: "contactnumber")
        print("created a new user.")
        print(defaults.object(forKey: "username") as! String)
        print(defaults.object(forKey: "userpassword")as! String)
        print(defaults.object(forKey: "contactname") as! String)
        print(defaults.object(forKey: "contactnumber") as! String)
        dismiss(animated: true, completion: nil)
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    

}
