//
//  SignInViewController.swift
//  mobileapp
//
//  Created by Vivian Zhang on 03/10/2017.
//  Copyright © 2017 Vivian Zhang. All rights reserved.
//

import UIKit

class SignInViewController: UIViewController, UITextFieldDelegate {

    @IBOutlet weak var userName: UITextField!
    @IBOutlet weak var password: UITextField!
    
    let defaults = UserDefaults.standard
    //var userFullNames = [String]()
    //var userPasswords = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        userName.delegate = self
        password.delegate = self
    }
   
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func resetButton(_ sender: Any) {
        resetField()
    }
    @IBAction func signInButton(_ sender: Any) {
        print("Sign in button tapped.")
        if (userName.text == "") || (password.text == ""){
            let emptyAlert = UIAlertController(title: "Oops", message: "Your username or password does not match our records!", preferredStyle: .alert)
            emptyAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(emptyAlert, animated: true, completion: nil)
            
        }
        // perform user authtication
        if defaults.object(forKey: "username") != nil {
            print("okkkk")
            let userFullName = defaults.object(forKey: "username") as! String
            let userPassword = defaults.object(forKey: "password") as! String
            if (userName.text! == userFullName) && (password.text! == userPassword) {
                print(userFullName)
                performSegue(withIdentifier: "signIn", sender:self)
            }
            //for x in 0...(userFullNames.count - 1){
                // Redirect user into our home page when authentication succeed
                //if (userName.text! == userFullNames[x]) && (password.text! == userPasswords[x]) {
                    //print(userFullNames[x])
                    //performSegue(withIdentifier: "signIn", sender:self)
                    //break
                //}
                
            //}
            resetField()
            // Pop up alert for incorrect username or password
            let unmatchAlert = UIAlertController(title: "Oops", message: "Your username or password does not match our records!", preferredStyle: .alert)
            unmatchAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(unmatchAlert, animated: true, completion: nil)
  
        } else {
            // Pop up alert for new user sign in
            let newUserAlert = UIAlertController(title: "Oops", message: "It seems like you are a new user, please sign up first!", preferredStyle: .alert)
            newUserAlert.addAction(UIAlertAction(title:"OK", style: .default, handler: nil))
            self.present(newUserAlert, animated: true, completion: nil)
        }
            
    }
    
    func resetField() {
        userName.text = ""
        password.text = ""
    }
    
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        userName.resignFirstResponder()
        password.resignFirstResponder()
        return true
    }
        
    
    
   // @IBAction func registerButton(_ sender: Any) {
        //print("New button tapped.")
        
        //instantiate a new register page from clicking the register button
        //let registerViewController = self.storyboard?.instantiateViewController(withIdentifier: "RegisterUserViewController")as!RegisterUserViewController
        //self.present(registerViewController, animated: true)
    //}
    
}
